package JDBCMariadb;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextPane;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.awt.event.ActionEvent;

public class Fenetre2 extends JFrame {

	private JPanel contentPane;
	private JTextField text_demande;
	private JLabel lblDate;
	private JTextField text_date;
	private static String pdemande;
	private static String pdate;
	private static String piduser;
	private JButton btndéconnecter;
	
	
		
	public JTextField getText_demande() {
		return text_demande;
	}


	public void setText_demande(JTextField text_demande) {
		this.text_demande = text_demande;
	}
	

	
	public Fenetre2() {
		setTitle("Client");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(650, 300, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		
				
		
		text_demande = new JTextField();
		text_demande.setBounds(173, 24, 147, 126);
		contentPane.add(text_demande);
		text_demande.setColumns(10);
		
		JLabel lblDemande = new JLabel("Demande :");
		lblDemande.setBounds(83, 77, 86, 19);
		contentPane.add(lblDemande);
		
		lblDate = new JLabel("Date :");
		lblDate.setBounds(110, 172, 59, 19);
		contentPane.add(lblDate);
		
		text_date = new JTextField();
		text_date.setColumns(10);
		text_date.setBounds(173, 162, 147, 42);
		contentPane.add(text_date);
		
		JButton btnValider = new JButton("Valider");
		btnValider.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				pdemande = text_demande.getText();
				pdate = text_date.getText();
				System.out.println(pdemande);
				System.out.println(pdate);
				JDBCBase.update_demande(pdemande,pdate, piduser);
				text_demande.setText("");
				text_date.setText("");
				
				
				
			}
		});
		btnValider.setBounds(12, 230, 169, 25);
		contentPane.add(btnValider);
		
		JButton btndéconnecter = new JButton("Se déconnecter");
		btndéconnecter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				setVisible(false);
				Fenetre1 fen1=new Fenetre1();
				fen1.setVisible(true);
				fen1.setTitle("Page d'accueil");
				
				
				
				
			}
		});
		btndéconnecter.setBounds(261, 230, 169, 25);
		contentPane.add(btndéconnecter);
		
		
		
		
		
		
	}
	
	
	public static String demande_recup() {
		String fct_demande = pdemande;
		return fct_demande;
	}
	
	
	public static String date_recup() {
		String fct_date = pdate;
		return fct_date;
	}
	
	public static String iduser_recup() {
		String fct_iduser = piduser;
		return fct_iduser;
	}

}

