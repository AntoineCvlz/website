package JDBCMariadb;


import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.awt.event.ActionEvent;

public class Fenetre1 extends JFrame {

	private JPanel contentPane;
	private JTextField text_user;
	private JTextField text_mdp;
	private Fenetre2 fen2;
	private Fenetre3 fen3;
	private static String puser;
	private static String pmdp;
	private static String prole;
	
	

	public Fenetre2 getFen2() {
		return fen2;
	}

	public void setFen2(Fenetre2 fen2) {
		this.fen2 = fen2;
	}
	

	public Fenetre3 getFen3() {
		return fen3;
	}

	public void setFen3(Fenetre3 fen3) {
		this.fen3 = fen3;
	}
	
	public JTextField getText_user() {
		return text_user;
	}

	public void setText_user(JTextField text_user) {
		this.text_user = text_user;
	}
	
	
	
	public Fenetre1() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(650, 300, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		text_user = new JTextField();
		text_user.setBounds(166, 71, 114, 19);
		contentPane.add(text_user);
		text_user.setColumns(10);
		

		
		text_mdp = new JTextField();
		text_mdp.setBounds(166, 130, 114, 19);
		contentPane.add(text_mdp);
		text_mdp.setColumns(10);
		
		
		JLabel lblUtilisateur = new JLabel("Utilisateur");
		lblUtilisateur.setBounds(53, 73, 106, 15);
		contentPane.add(lblUtilisateur);
		
		JLabel lblMotDePasse = new JLabel("Mot de passe");
		lblMotDePasse.setBounds(53, 132, 106, 15);
		contentPane.add(lblMotDePasse);
		
		JButton btnGo = new JButton("GO");
		
		


		btnGo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				puser = text_user.getText();
				pmdp = text_mdp.getText();
				
				if (JDBCBase.authentification(puser, pmdp).equals("OK")) {
					
					
					
					if (JDBCBase.authentification_admin(prole).equals("OK")) {
						
						setVisible(false);
						Fenetre3 fen3 = new Fenetre3();
						fen3.setVisible(true);
						
						
					}
					

					
					else {
						setVisible(false);
						Fenetre2 fen2 = new Fenetre2();
						fen2.setVisible(true);
						fen2.setTitle("Client");
						
						
					}
				}
				else {
					setVisible(false);
					FenetreErreur fen4 = new FenetreErreur();
					fen4.setVisible(true);
					fen4.setTitle("Erreur d'identification");
				}
			}
		});
		btnGo.setBounds(163, 202, 117, 25);
		contentPane.add(btnGo);
		
	} 
	
	public static String user_recup() {
		String fct_user = puser;
		return fct_user;
	}
	
	public static String mdp_recup() {
		String fct_mdp = pmdp;
		return fct_mdp;
	}
	
	public static String role_recup() {
		String fct_role = prole;
		return fct_role;
	}
	
	
	
}