package JDBCMariadb;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;

public class Main {

	public static void main(String[] args) {
		
		Fenetre1 fen1 = new Fenetre1();
		fen1.setVisible(true);
		fen1.setTitle("Page d'accueil");

		
	}
}
