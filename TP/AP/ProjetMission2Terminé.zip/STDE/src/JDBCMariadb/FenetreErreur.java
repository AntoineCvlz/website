package JDBCMariadb;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.SwingConstants;

public class FenetreErreur extends JFrame {

	private JPanel contentPane;
	private JTextField txtErreur;

	public FenetreErreur() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtErreur = new JTextField();
		txtErreur.setHorizontalAlignment(SwingConstants.CENTER);
		txtErreur.setFont(new Font("Dialog", Font.PLAIN, 15));
		txtErreur.setEditable(false);
		txtErreur.setText("ERREUR !!!");
		txtErreur.setBounds(113, 87, 169, 83);
		contentPane.add(txtErreur);
		txtErreur.setColumns(10);
	}
}
