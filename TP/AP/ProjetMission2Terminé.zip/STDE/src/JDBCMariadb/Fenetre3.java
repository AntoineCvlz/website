package JDBCMariadb;


import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JEditorPane;
import javax.swing.JTextArea;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JComboBox;

public class Fenetre3 extends JFrame {

	private JPanel contentPane;
	private static String petat;
	private static String ppriorite;
	private static String presponsable;
	private static String plibelle;
	private Fenetre1 fen1;
	private Fenetre3 fen3;
	
	
	public Fenetre1 getFen1() {
		return fen1;
	}

	public void setFen1(Fenetre1 fen1) {
		this.fen1 = fen1;
	}
	
	
	public Fenetre3 getFen3() {
		return fen3;
	}

	public void setFen3(Fenetre3 fen3) {
		this.fen3 = fen3;
	}
	
	
	

	
	public Fenetre3() {
		setTitle("Administrateur");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(650, 300, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		
		
		JLabel lblDemande = new JLabel("Demande :");
		lblDemande.setBounds(91, 64, 86, 19);
		contentPane.add(lblDemande);
		
		
		
		
		JLabel lblPriorité = new JLabel("Priorité  :");
		lblPriorité.setBounds(100, 131, 77, 19);
		contentPane.add(lblPriorité);
		
		
		
		
		JLabel lblResponsablité = new JLabel("Responsabilité :");
		lblResponsablité.setBounds(52, 162, 123, 19);
		contentPane.add(lblResponsablité);
		
		
		
		
		
		
		
		
		JLabel lblEtat = new JLabel("Etat  :");
		lblEtat.setBounds(124, 100, 65, 19);
		contentPane.add(lblEtat);
		
		
		
		
		
		JComboBox comboBoxDemande = new JComboBox();
		JDBCBase.differentes_demande(comboBoxDemande);
		comboBoxDemande.setBounds(190, 61, 213, 24);
		contentPane.add(comboBoxDemande);
		
		
		
		
		
		
		
		
		
		JComboBox comboBoxEtat = new JComboBox();
		comboBoxEtat.setBounds(190, 95, 117, 24);
		contentPane.add(comboBoxEtat);
		comboBoxEtat.addItem("En attente");
		comboBoxEtat.addItem("En cours");
		comboBoxEtat.addItem("Terminé");
		
		JComboBox comboBoxPriorite = new JComboBox();
		comboBoxPriorite.setBounds(190, 128, 117, 24);
		contentPane.add(comboBoxPriorite);
		comboBoxPriorite.addItem("Non urgent");
		comboBoxPriorite.addItem("Urgent");
	
		
		
		
		
		
		
		JComboBox comboBoxResponsabilite = new JComboBox();
		comboBoxResponsabilite.setBounds(190, 162, 117, 24);
		JDBCBase.different_nom(comboBoxResponsabilite);
		contentPane.add(comboBoxResponsabilite);
		
		
		
		
		
		JButton btnValider = new JButton("Valider");
		btnValider.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				JDBCBase.update_admin(comboBoxDemande, comboBoxPriorite,comboBoxEtat );
				JDBCBase.update_role(comboBoxResponsabilite, comboBoxDemande);
				comboBoxDemande.removeAllItems();
				JDBCBase.differentes_demande(comboBoxDemande);
				System.out.println("Modifications apportées");
				
				
				
				
				 
			}
		});
		btnValider.setBounds(25, 230, 169, 25);
		contentPane.add(btnValider);
		
		JButton btndéconnecter = new JButton("Se déconnecter");
		btndéconnecter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				setVisible(false);
				Fenetre1 fen1=new Fenetre1();
				fen1.setVisible(true);
				fen1.setTitle("Page d'accueil");
				
				
				
				
			}
		});
		btndéconnecter.setBounds(261, 230, 169, 25);
		contentPane.add(btndéconnecter);
		
		
		
		
		
		
	}
	
	
	
	
	public static String etat_recup() {
		String fct_etat = petat;
		
		return fct_etat;
	}
	
	public static String priorite_recup() {
		String fct_priorite = ppriorite;
		return fct_priorite;
	}
	
	
	public static String responsable_recup() {
		String fct_responsable = presponsable;
		return fct_responsable;
	}
	
	public static String libelle_recup() {
		String fct_libelle = plibelle;
		return fct_libelle;
	}
}




