package JDBCMariadb;

import java.sql.*;

import javax.swing.JComboBox;


public class JDBCBase {
    // nom du driver,host,BDD
	
	private ResultSet result;
	private ResultSetMetaData resultMeta;
	
	
	
	//GETTER SETTER

    public ResultSet getResult() {
		return this.result;
	}


	public void setResult(ResultSet result) {
		this.result = result;
	}
 

	public ResultSetMetaData getResultMeta() {
		return this.resultMeta;
	}


	public void setResultMeta(ResultSetMetaData resultMeta) {
		this.resultMeta = resultMeta;
	}








	static final String JDBC_DRIVER = "org.mariadb.jdbc.Driver";
    static final String DB_URL = "jdbc:mariadb://localhost/Mission2";

    // loggin
    static final String USER = "root";
    static final String PASS = "root";
    
    
    public JDBCBase() {
        Connection conn = null;
        Statement stmt = null;
     
        try {
        	
        	
            //Enregistrement du driver
            Class.forName("org.mariadb.jdbc.Driver");
            //Class.forName(JDBC_DRIVER);

            //Ouverture de la connection
            //System.out.println("Connecting to a selected database...");
            conn = DriverManager.getConnection("jdbc:mariadb://localhost/Mission2", "root", "root");
            //conn = DriverManager.getConnection(DB_URL);
            //System.out.println("Connected database successfully...");

            //Execute une requete           
            stmt = conn.createStatement();
            //DÃ©finition de la requete.
            String sql = "select * from Utilisateur ";
                
            //ici on execute note commande sql
            this.result=stmt.executeQuery(sql);
            this.resultMeta = result.getMetaData();
            
            //result contient le resultat de la requete sous forme de Resultset
            //resultMetat les colonnes les metadata.
            //System.out.println("*****************************************");
            //System.out.println("****AFFICHAGE DES DATA******");
            //System.out.println("*****************************************");
            //System.out.println("\n");
          
              
          
          //On affiche le nom des colonnes
			
			  for(int i = 1; i <= resultMeta.getColumnCount(); i++) {
				  //System.out.print("\t"+ resultMeta.getColumnName(i).toUpperCase() + "\t*");
			  }
			  System.out.println();
			
			
			
			
			
 
           // affichage des donnÃ©es
			
            /*while(result.next()){         
                for(int i = 1; i <= resultMeta.getColumnCount(); i++) {
                	 //System.out.print("\t"+ result.getObject(i).toString()+"\t");        	 
                }
                System.out.println();
            }*/        
              
        } 
        catch (Exception e) {
            
            e.printStackTrace();    
        }
        
        
        //System.out.println("FIN");
    }//end constructor
    
    public static String authentification(String puser, String pmdp) {
    	Connection conn = null;
        Statement stmt = null;
        String test = "notOK";
        String user=Fenetre1.user_recup();
        String mdp=Fenetre1.mdp_recup();
    	
    	try {
    		//Enregistrement du driver
            Class.forName(JDBC_DRIVER);

            //Ouverture de la connection
            //System.out.println("Connecting to a selected database...");
            conn = DriverManager.getConnection("jdbc:mariadb://localhost/Mission2", "root", "root");
            //conn = DriverManager.getConnection(DB_URL);
            //System.out.println("Connected database successfully...");
            
            //Execute une requete           
            stmt = conn.createStatement();
            //DÃ©finition de la requete.
            String sql = "select mdp from Utilisateur where user = \""+ user + "\"";
            
            //ici on execute note commande sql
            ResultSet result=stmt.executeQuery(sql);
            ResultSetMetaData resultMeta = result.getMetaData();
            
            //On affiche le nom des colonnes
			  for(int i = 1; i <= resultMeta.getColumnCount(); i++) {
				  //System.out.print("\t\t"+ resultMeta.getColumnName(i).toUpperCase() + "\t\t *");
			  }
			//System.out.println();
			
 
			// affichage des donnÃ©es
            while(result.next()){       
                for(int i = 1; i <= resultMeta.getColumnCount(); i++) {
                	 //System.out.print("\t\t"+ result.getObject(i).toString()+"\t\t");
                	 if (result.getObject(1).equals(mdp)) {
     	            	test = "OK";
     	            }else {
     	            	test = "notOK";
     	            }
                }
                System.out.println();
            }  
         
    	}catch (Exception e) {
    		e.printStackTrace();
    	}
    	return test;
    }//Fin Auth
    
    
    
    
    public static String authentification_admin(String prole) {
    	Connection conn = null;
        Statement stmt = null;
        String test2 = "notOK";
        String user=Fenetre1.user_recup();
        String mdp=Fenetre1.mdp_recup();
        String role=Fenetre1.role_recup();
    	
    	try {
    		//Enregistrement du driver
            Class.forName(JDBC_DRIVER);

            //Ouverture de la connection
            //System.out.println("Connecting to a selected database...");
            conn = DriverManager.getConnection("jdbc:mariadb://localhost/Mission2", "root", "root");
            //conn = DriverManager.getConnection(DB_URL);
            //System.out.println("Connected database successfully...");
            
            //Execute une requete           
            stmt = conn.createStatement();
            //DÃ©finition de la requete.
            String sql = "select role,id_user from Utilisateur where user = \""+ user + "\"";
            
            //ici on execute note commande sql
            ResultSet result=stmt.executeQuery(sql);
            ResultSetMetaData resultMeta = result.getMetaData();
            
            //On affiche le nom des colonnes
			  for(int i = 1; i <= resultMeta.getColumnCount(); i++) {
				  //System.out.print("\t\t"+ resultMeta.getColumnName(i).toUpperCase() + "\t\t *");
			  }
			//System.out.println();
			
 
			// affichage des donnÃ©es
            while(result.next()){       
                for(int i = 1; i <= resultMeta.getColumnCount(); i++) {
                	 //System.out.print("\t\t"+ result.getObject(i).toString()+"\t\t");
                	
                	 if (result.getObject(1).equals("admin")) {
     	            	test2 = "OK";
     	            }else {
     	            	test2 = "notOK";
     	            }
                }
                System.out.println();
            }  
         
    	}catch (Exception e) {
    		e.printStackTrace();
    	}
    	return test2;
    }//Fin Auth
    
    
    
    
    
    public static String update_demande(String pdemande, String pdate, String iduser) {
    	Connection conn = null;
        Statement stmt = null;
        
        String user=Fenetre1.user_recup();
        String demande=Fenetre2.demande_recup();
        String date=Fenetre2.date_recup();
        
    	
    	try {
    		 //Enregistrement du driver
            Class.forName("org.mariadb.jdbc.Driver");
            //Class.forName(JDBC_DRIVER);

            //Ouverture de la connection
            //System.out.println("Connecting to a selected database...");
            conn = DriverManager.getConnection("jdbc:mariadb://localhost/Mission2", "root", "root");
            //conn = DriverManager.getConnection(DB_URL);
            //System.out.println("Connected database successfully...");

            //Execute une requete           
            stmt = conn.createStatement();
			//DÃ©finition de la requete.
            String sql = "INSERT INTO Demande (id_demande, libelle, `date_demande`, priorite, etat, id_user) VALUES(0, '"+demande+"', '"+date+"', 'Non urgent', 'En attente',NULL)";
            
                
            //ici on execute note commande sql
            ResultSet result=stmt.executeQuery(sql);
            ResultSetMetaData resultMeta = result.getMetaData();
    		 
            
           
                
          
        
            
            //On affiche le nom des colonnes
			  for(int i = 1; i <= resultMeta.getColumnCount(); i++) {
				  //System.out.print("\t\t"+ resultMeta.getColumnName(i).toUpperCase() + "\t\t *");
			  }
			//System.out.println();
			  while(result.next()){       
	                for(int i = 1; i <= resultMeta.getColumnCount(); i++) {
	                	 //System.out.print("\t\t"+ result.getObject(i).toString()+"\t\t");
	                	
	                	 
	                }
	                System.out.println();
	            }  
 
			
            
         
    	}catch (Exception e) {
    		e.printStackTrace();
    	}
		return date;
    	
    }//Fin update demande
    
    
    
    
    
    
    
    
    
    
    public static void differentes_demande(JComboBox comboBoxDemande) {
    	Connection conn = null;
        Statement stmt = null;
        
       // String demande=Fenetre2.demande_recup();
        
        
    	
    	try {
    		//Enregistrement du driver
            Class.forName(JDBC_DRIVER);

            //Ouverture de la connection
            //System.out.println("Connecting to a selected database...");
            conn = DriverManager.getConnection("jdbc:mariadb://localhost/Mission2", "root", "root");
            //conn = DriverManager.getConnection(DB_URL);
            //System.out.println("Connected database successfully...");
            
            //Execute une requete           
            stmt = conn.createStatement();
            //DÃ©finition de la requete.
            String sql = "select libelle from Demande where etat = 'En attente' or etat = 'En cours'";
            
            //ici on execute note commande sql
            ResultSet result=stmt.executeQuery(sql);
            ResultSetMetaData resultMeta = result.getMetaData();
            
            //On affiche le nom des colonnes
			  for(int i = 1; i <= resultMeta.getColumnCount(); i++) {
				  //System.out.print("\t\t"+ resultMeta.getColumnName(i).toUpperCase() + "\t\t *");
			  }
			//System.out.println();
			
 
			// affichage des donnÃ©es
            while(result.next()){       
            	 comboBoxDemande.addItem(result.getObject(1).toString());
                
            }  
         
    	}catch (Exception e) {
    		e.printStackTrace();
    	}
    	
    }//Fin differente demande
    
    
    
    
    
    public static void different_nom(JComboBox comboBoxResponsabilite) {
    	Connection conn = null;
        Statement stmt = null;
        
       // String demande=Fenetre2.demande_recup();
        
        
    	
    	try {
    		//Enregistrement du driver
            Class.forName(JDBC_DRIVER);

            //Ouverture de la connection
            //System.out.println("Connecting to a selected database...");
            conn = DriverManager.getConnection("jdbc:mariadb://localhost/Mission2", "root", "root");
            //conn = DriverManager.getConnection(DB_URL);
            //System.out.println("Connected database successfully...");
            
            //Execute une requete           
            stmt = conn.createStatement();
            //DÃ©finition de la requete.
            String sql = "select user from Utilisateur";
            
            //ici on execute note commande sql
            ResultSet result=stmt.executeQuery(sql);
            ResultSetMetaData resultMeta = result.getMetaData();
            
            //On affiche le nom des colonnes
			  for(int i = 1; i <= resultMeta.getColumnCount(); i++) {
				  //System.out.print("\t\t"+ resultMeta.getColumnName(i).toUpperCase() + "\t\t *");
			  }
			//System.out.println();
			
 
			// affichage des donnÃ©es
            while(result.next()){       
            	 comboBoxResponsabilite.addItem(result.getObject(1).toString());
                
            }  
         
    	}catch (Exception e) {
    		e.printStackTrace();
    	}
    	
    }//Fin differente demande
        
        
    
    
    
    
    public static void update_admin(JComboBox comboBoxDemande, JComboBox  comboBoxPriorite, JComboBox comboBoxEtat ) {
    	Connection conn = null;
        Statement stmt = null;
        
        
        String etat=comboBoxEtat.getSelectedItem().toString();
        String priorite=comboBoxPriorite.getSelectedItem().toString();
        String libelle = comboBoxDemande.getSelectedItem().toString();
        //String id_user= Fenetre2.iduser_recup();
      //  String responsable = comboBoxResponsable.getSelectedItem().toString();
        
        //String responsable=Fenetre3.responsable_recup();
    	
    	try {
    		 //Enregistrement du driver
            Class.forName("org.mariadb.jdbc.Driver");
            //Class.forName(JDBC_DRIVER);

            //Ouverture de la connection
            //System.out.println("Connecting to a selected database...");
            conn = DriverManager.getConnection("jdbc:mariadb://localhost/Mission2", "root", "root");
            //conn = DriverManager.getConnection(DB_URL);
            //System.out.println("Connected database successfully...");

            //Execute une requete           
            stmt = conn.createStatement();
			//DÃ©finition de la requete.
            String sql = "UPDATE Demande SET priorite='"+priorite+"', etat='"+etat+"' where libelle ='"+libelle+"'";
            
                
            //ici on execute note commande sql
            ResultSet result=stmt.executeQuery(sql);
            ResultSetMetaData resultMeta = result.getMetaData();
            
            
            
            
          
            
            
            //On affiche le nom des colonnes
			  for(int i = 1; i <= resultMeta.getColumnCount(); i++) {
				  //System.out.print("\t\t"+ resultMeta.getColumnName(i).toUpperCase() + "\t\t *");
			  }
			//System.out.println();
			  while(result.next()){       
	                for(int i = 1; i <= resultMeta.getColumnCount(); i++) {
	                	 //System.out.print("\t\t"+ result.getObject(i).toString()+"\t\t");
	                	
	                	 
	                }
	                System.out.println();
	            }  
 
			
            
         
    	}catch (Exception e) {
    		e.printStackTrace();
    	}
		
    	
    }//Fin update admin
    
    
    
    
    
    
    
    public static void update_role(JComboBox comboBoxResponsabilite,JComboBox comboBoxDemande) {
    	Connection conn = null;
        Statement stmt = null;
        
        
        String nom_responsable=comboBoxResponsabilite.getSelectedItem().toString();
        String libelle = comboBoxDemande.getSelectedItem().toString();
        String recup_id_user="";
        
        //String id_user= Fenetre2.iduser_recup();
      //  String responsable = comboBoxResponsable.getSelectedItem().toString();
        
        //String responsable=Fenetre3.responsable_recup();
    	
    	try {
    		 //Enregistrement du driver
            Class.forName("org.mariadb.jdbc.Driver");
            //Class.forName(JDBC_DRIVER);

            //Ouverture de la connection
            //System.out.println("Connecting to a selected database...");
            conn = DriverManager.getConnection("jdbc:mariadb://localhost/Mission2", "root", "root");
            //conn = DriverManager.getConnection(DB_URL);
            //System.out.println("Connected database successfully...");

            //Execute une requete           
            stmt = conn.createStatement();
			//DÃ©finition de la requete.
            String sql = "select id_user from Utilisateur where user = '"+nom_responsable+"'";
            
            
                
            //ici on execute note commande sql
            ResultSet result=stmt.executeQuery(sql);
            ResultSetMetaData resultMeta = result.getMetaData();
            
            
            
            
          
            
            
            //On affiche le nom des colonnes
			  for(int i = 1; i <= resultMeta.getColumnCount(); i++) {
				  
			  }
			//System.out.println();
			  while(result.next()){       
	                for(int i = 1; i <= resultMeta.getColumnCount(); i++) {
	                	 recup_id_user=result.getObject(1).toString();
	                	
	                	 
	                }
	                System.out.println();
	            }  
			  
			  	System.out.println(libelle);
				
	            sql = "UPDATE Demande SET id_user ='"+recup_id_user+"' where libelle='"+libelle+"'";
	            
	            
	            
			
	            stmt = conn.createStatement();
	            stmt.executeUpdate(sql);
         
    	}catch (Exception e) {
    		e.printStackTrace();
    	}
		
    	
    }//Fin update role
    
    
    
    
    
    
    
    
    
    
    
    
    
    
   
        
        
        //System.out.println("FIN");
    }

