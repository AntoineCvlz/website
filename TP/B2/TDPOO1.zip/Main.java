import java.util.Random;

public class Main {

	public static void main(String[] args) {
		Random random = new Random();
		int vie = random.nextInt(500);
		int force = random.nextInt(50);
		int degat= random.nextInt(50);
		int dexterite= random.nextInt(50);
		int intel= random.nextInt(50);
		
		
		Guerrier g1=new Guerrier("Hector",vie,force,dexterite,intel,"H");
		Guerrier g2=new Guerrier("Achile",500,2,50,1,"H");
		
		while (g1.getVivant()  && g2.getVivant()){
			
			//g2 attaque g1
			g1.setVie(g1.getVie()-g2.attaque());
			System.out.println(g1);
			System.out.println(g2);
				if (g1.getVivant()==false) {break;}
			//g1 attaque g2
			g2.setVie(g2.getVie()-g1.attaque());
			System.out.println(g1);
			System.out.println(g2);
		}
		
		

	}

}
