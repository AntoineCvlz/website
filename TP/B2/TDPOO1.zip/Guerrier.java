import java.util.Random;

public class Guerrier extends Personnage{
	
	protected int armure;
	protected int degat=10;
	
	public void combat(Guerrier pg,Armee ar1,Armee ar2)
	{
		while (this.getVivant()  && pg.getVivant())
		{
			
			//g2 attaque g1
			this.setVie(this.getVie()-pg.attaque());
				if (this.getVivant()==false) {break;}
			//g1 attaque g2
			pg.setVie(pg.getVie()-this.attaque());
		}// fin while
		
		if (! this.getVivant())
		{ar1.setNbrVivant(ar1.getNbrVivant()-1);}
		
		
		if (! pg.getVivant())
		{ar2.setNbrVivant(ar2.getNbrVivant()-1);}
		
	}
	public int attaque() {
		int res=0;
		Random random = new Random();
		res = random.nextInt(this.degat+1);
		return res;
	}
	
	public String toString ()
	{
		
		return "prenom :"+this.prenom+" "+"Vie:"+this.vie;
	}

	
	//CONSTRUCTEUR
	public Guerrier(String prenom,int vie,int force,int dexterite,int intel,String genre){
		this.prenom=prenom;
		this.vie=vie;
		this.force=force;
		this.dexterite=dexterite;
		this.intel=intel;
		this.genre=genre;
		Personnage.nbPersonnage+=1;
		
	}

}
