import java.util.ArrayList;
import java.util.Random;

public class Armee {
	
	//attributs
	ArrayList<Guerrier> tab =new ArrayList<Guerrier>();
	int nbrVivant;
	int nbmax;
	
	
	//constructeur
	public Armee(int nbMax,int pMaxVie) 
	{
	
		int maxForce=50;
		int maxDext=50;
		int maxIntel=50;
		int maxDegat=10;
		
		this.nbmax=nbMax;
		for(int i=0;i<nbMax;i++)
		{
			
			Random random = new Random();
			int vie = random.nextInt(pMaxVie);
			int force = random.nextInt(maxForce);
			int degat= random.nextInt(maxDegat);
			int dexterite= random.nextInt(maxDext);
			int intel= random.nextInt(maxIntel);
			
			
			Guerrier g=new Guerrier("guerrier"+i,vie,force,dexterite,intel,"F");
			this.tab.add(g);
			this.nbrVivant+=1;
		
		
		}
	

		
		
		
		
	}//fin constructeur

	public void attaque(Armee pa)
	{
		for(int i=0;i<this.nbmax;i++)
		{
			for(int j=0;j<pa.nbmax;j++)
			{
				if (this.tab.get(i).getVivant() && pa.tab.get(j).getVivant())
				{
				
				this.tab.get(i).combat(pa.tab.get(j),this,pa);
				}//fin if
				
					
			}//fin for
				
				
		}//fin for
			
		}//fin methode attaque
	
	

	//getter setter

	public ArrayList<Guerrier> getTab() {
		return tab;
	}


	public void setTab(ArrayList<Guerrier> tab) {
		this.tab = tab;
	}


	public int getNbrVivant() {
		return nbrVivant;
	}


	public void setNbrVivant(int nbrVivant) {
		this.nbrVivant = nbrVivant;
	}
}//fin classe

