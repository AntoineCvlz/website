
public class Personnage {
	protected String prenom;
	protected int vie=500;
	protected int force=25;
	protected int dexterite=50;
	protected int intel=15;
	protected String genre;
	protected Boolean vivant=true;
	//attribut de classe independant des objet instanciés.
	protected static int nbPersonnage;
	
	
	//Getter Setter
	
	public String getPrenom() {
		return prenom;
	}
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	public int getVie() {
		return vie;
	}
	
	
	//ICI le booleen vivant est automatiquement mis à jour.
	public void setVie(int vie) {
		this.vie = vie;
		if (this.vie <+0){
			this.vivant=false;
			Personnage.nbPersonnage-=1;
		}
	}
	public int getForce() {
		return force;
	}
	public void setForce(int force) {
		this.force = force;
	}
	public int getDexterite() {
		return dexterite;
	}
	public void setDexterite(int dexterite) {
		this.dexterite = dexterite;
	}
	public int getIntel() {
		return intel;
	}
	public void setIntel(int intel) {
		this.intel = intel;
	}
	public String gGuerreetGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	public Boolean getVivant() {
		return vivant;
	}
	public void setVivant(Boolean vivant) {
		this.vivant = vivant;
	}
	
	//getter et setter definis en static car nbPersonnage est un attribut static
	public static int getNbPersonnage() {
		return nbPersonnage;
	}
	public static void setNbPersonnage(int nbPersonnage) {
		Personnage.nbPersonnage = nbPersonnage;
	}

	
	
	
	
}
