
public class MainArmee2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
			Armee a_velocipraptor=new Armee(120,200);
			Armee a_diplodocus=new Armee(12,2000);
			
			a_velocipraptor.attaque(a_diplodocus);
			
			System.out.println("armee1:"+a_velocipraptor.getNbrVivant());
			System.out.println("armee2:"+a_diplodocus.getNbrVivant());
	}

}
