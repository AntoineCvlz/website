package JDBCMariadb;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class fen1 extends JFrame {
	private JPanel contentPane;
	private fen2 fen_suiv;
	private fen3 fen_erreur;
	private JTextField textnom;
	private JTextField textmdp;
	
	String mdpbdd="";
	String nombdd="";
	

	
	
	
	
	
	public fen2 getFen_suiv() {
		return fen_suiv;
	}

	
	

	public void setFen_suiv(fen2 fen2) {
		this.fen_suiv = fen2;
	}
	
	
	
	
	public fen3 getFen_erreur() {
		return fen_erreur;
	}

	
	

	public void setFen_erreur(fen3 fen3) {
		this.fen_erreur = fen3;
	}
	
	
	
	public void clic_go(String nom, String mdp) {
		
		JDBCBase bdd=new JDBCBase();

		
		ResultSet result=bdd.getResult();
		
		ResultSetMetaData resultMeta = bdd.getResultMeta();
		
		
		try {
		
		while(result.next()) {
			
				mdpbdd = result.getObject(1).toString();
				nombdd= result.getObject(2).toString();
			}
		}
		catch (Exception e) {
            
            e.printStackTrace();    
        }
		
		
		/*System.out.println(nom);
		System.out.println(nombdd);
		
		System.out.println(mdp);
		System.out.println(mdpbdd);
		*/
		if(mdpbdd.equals(mdp) && nombdd.equals(nom))  {
			System.out.println("Identification réussite");
			this.setVisible(false);
			this.fen_suiv.setVisible(true);
		}
		else
		{
			System.out.println("Identification incorrect");
			this.setVisible(false);
			this.fen_erreur.setVisible(true);
		}
		
		
		 
		
		
		
			}
	
	


			
		
		
		
	
		
	
	
	
	
	
	
	
	
	
	
	public fen1() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		
		
		JLabel lblNomDutilisateur = new JLabel("Nom d'utilisateur :");
		lblNomDutilisateur.setBounds(12, 90, 147, 15);
		contentPane.add(lblNomDutilisateur);
		
		textnom = new JTextField();
		textnom.setBounds(159, 88, 99, 19);
		contentPane.add(textnom);
		textnom.setColumns(10);
		
		
		
		JLabel lblMdp = new JLabel("MDP :");
		lblMdp.setBounds(102, 131, 44, 15);
		contentPane.add(lblMdp);
		
		
		textmdp = new JTextField();
		textmdp.setColumns(10);
		textmdp.setBounds(159, 129, 99, 19);
		contentPane.add(textmdp);
		
		
		
		
		
		
		JButton btnGo = new JButton("Go");
		btnGo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				
				clic_go(textnom.getText(),textmdp.getText());
				
				
				
				
			}
		});
		
		btnGo.setBounds(356, 230, 74, 25);
		contentPane.add(btnGo);
	
		
	
		
	}

	

	
	
	
	
	

	
	
	

	


	
	
	
	
	
	
	
	
	

	
	
	
	
	
	

}