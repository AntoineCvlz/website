package JDBCMariadb;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;

public class Main {

	public static void main(String[] args) {
		
		
		
		fen1 fen1 = new fen1();
		fen1.setVisible(true);
		fen1.setTitle("fen1");
		
		fen2 fen2= new fen2();
		fen2.setVisible(false);
		fen2.setTitle("fen2");
		
		fen3 fen3= new fen3();
		fen3.setVisible(false);
		fen3.setTitle("fen3");
		
		fen1.setFen_suiv(fen2);
		
		fen1.setFen_erreur(fen3);
		
		
		
		
		
		
		
		

}
}
