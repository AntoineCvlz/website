package JDBCMariadb;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class fen2 extends JFrame {
	
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JButton btnDepot;
	private JButton btnRetrait;
	
	public fen2() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		
		
	
		
		
		
		JLabel lblDepot = new JLabel("Solde :");
		lblDepot.setBounds(82, 90, 74, 15);
		contentPane.add(lblDepot);
		
		textField = new JTextField();
		textField.setBounds(159, 88, 99, 19);
		contentPane.add(textField);
		textField.setColumns(10);
		
		
		
		JLabel lblRetrait = new JLabel("Montant :");
		lblRetrait.setBounds(82, 131, 74, 15);
		contentPane.add(lblRetrait);
		
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(159, 129, 99, 19);
		contentPane.add(textField_1);
		
		btnDepot = new JButton("Depot");
		btnDepot.setBounds(12, 205, 117, 25);
		contentPane.add(btnDepot);
		
		btnRetrait = new JButton("Retrait");
		btnRetrait.setBounds(275, 205, 117, 25);
		contentPane.add(btnRetrait);
	}
	
	
	
	
	

	


	
	
	
	
	
	
	
		
		
		
		
		
					
				
				
				
				
				
				
				
				
		
		
		
		
	
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
				
	

	
	



