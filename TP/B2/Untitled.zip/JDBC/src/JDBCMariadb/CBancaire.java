package JDBCMariadb;

public class CBancaire {

		private double m_solde;
		
		
		public CBancaire(){
		m_solde = 152.25;
		}
		
		public CBancaire(double x){
		m_solde = x;
		}
		
		public double getSolde(){
		return m_solde;
		}
		public void retrait(double x){
		m_solde += x;
		}
		public void debit(double x){
		m_solde -= x;
		}
		public void afficher(){
		System.out.println(getSolde() + " euros");
		}
		public void virerVers(CBancaire cb, double mt){
		cb.retrait(mt);
		debit(mt);

}
}
