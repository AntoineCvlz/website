package JDBCMariadb;

import java.sql.*;

public class JDBCBase {
    // nom du driver,host,BDD
	

    static final String JDBC_DRIVER = "org.mariadb.jdbc.Driver";
    static final String DB_URL = "jdbc:mariadb://localhost/Banque";

    // loggin
    static final String USER = "root";
    static final String PASS = "root";
    
    private ResultSet result;
    private ResultSetMetaData resultMeta;
    
    
    
    
    
    
    
    
    public ResultSet getResult() {
		return result;
	}








	public void setResult(ResultSet result) {
		this.result = result;
	}
	
	
	
	
	




	public ResultSetMetaData getResultMeta() {
		return resultMeta;
	}








	public void setResultMeta(ResultSetMetaData resultMeta) {
		this.resultMeta = resultMeta;
	}








	public JDBCBase() {
        Connection conn = null;
        Statement stmt = null;
        
     
        try {
        	
        	
            //Enregistrement du driver
            Class.forName("org.mariadb.jdbc.Driver");
            //Class.forName(JDBC_DRIVER);

            //Ouverture de la connection
            //System.out.println("Connecting to a selected database...");
            conn = DriverManager.getConnection("jdbc:mariadb://localhost:3306/Banque", "root", "root");
            //conn = DriverManager.getConnection(DB_URL);
            //System.out.println("Connected database successfully...");

            //Execute une requete           
            stmt = conn.createStatement();
            //Définition de la requete.
            String sql = "select * from Compte ";
                
            //ici on execute note commande sql
            this.result=stmt.executeQuery(sql);
            this.resultMeta = result.getMetaData();
            
            //result contient le resultat de la requete sous forme de Resultset
            //resultMetat les colonnes les metadata.
            //System.out.println("*****************************************");
            //System.out.println("****AFFICHAGE DES DATA******");
            //System.out.println("*****************************************");
            
          
              
          
          //On affiche le nom des colonnes
			
			  for(int i = 1; i <= resultMeta.getColumnCount(); i++) {
				  //System.out.print("\t\t"+ resultMeta.getColumnName(i).toUpperCase() + "\t\t *");
			  }
			System.out.println();
			
			
			
			
			
 
           // affichage des données
			
            /*while(result.next()){         
                for(int i = 1; i <= resultMeta.getColumnCount(); i++) {
                	 System.out.print("\t\t"+ result.getObject(i).toString()+"\t\t");        	 
                }
                System.out.println();
            }   */     
           
            
            
            
            
            
        } catch (Exception e) {
            
            e.printStackTrace();    
        }
        
        
        //System.out.println("FIN");
    }//end main
}//end class
