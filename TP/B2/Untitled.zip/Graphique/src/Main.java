import java.awt.Color;

public class Main {

	public static void main(String[] args) {
		Fen1 toto=new Fen1();
		toto.setVisible(true);
		
		toto.getContentPane().setBackground(Color.BLACK);

	}

}
