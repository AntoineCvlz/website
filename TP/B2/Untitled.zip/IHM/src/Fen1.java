import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;

public class Fen1 extends JFrame {

	private JPanel contentPane;

	
	public Fen1() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(null);
		
		ArrayList<JButton> tabBouton=new ArrayList<JButton>();
		
		for (int i=0;i<100;i++) {
			tabBouton.add(new JButton("b"+i));
		}
		int i= 0;
		
		for(int t=0;t<500;t=t+50) {
			
		
		for (int k=0;k<500;k=k+50) {
			tabBouton.get(i).setBounds(k, t, 50, 50);
			getContentPane().add(tabBouton.get(i));
			i=i+1;
		}
	}
}}
