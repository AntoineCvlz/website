import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Fen2 extends JFrame {

	private JPanel contentPane;
	private int decalage;
	
	
	
	public void clic_btn_BAS(int p) {
		
		
		this.setBounds(100, this.getBounds().y+50, 600, 600);
	}
	
	
	
	public void clic_btn_HAUT(int p) {
		
		this.setBounds(100, this.getBounds().y-50, 600, 600);
		
	}
	
	public void clic_btn_GAUCHE(int p) {
		
		this.setBounds(100, this.getBounds().y-50, 600, 600);
		
	}
	
	
	public void clic_btn_DROITE(int p) {
		
		this.setBounds(100, this.getBounds().y-50, 600, 600);
		
	}
	
	
	
	
	
	
	public Fen2() {
		
	
		
		
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		

		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		
		
		JButton btn_HAUT= new JButton("HAUT");
		btn_HAUT.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				clic_btn_HAUT(50);
			}
		});
		btn_HAUT.setBounds(170, 50, 100, 35);
		contentPane.add(btn_HAUT);
		
		
		
		
		JButton btn_BAS= new JButton("BAS");
		btn_BAS.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				clic_btn_BAS(50);
			}
		});
		btn_BAS.setBounds(170, 200, 100, 35);
		contentPane.add(btn_BAS);
		
		
		
		JButton btn_GAUCHE= new JButton("GAUCHE");
		btn_GAUCHE.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				clic_btn_GAUCHE(50);
			}
		});
		btn_GAUCHE.setBounds(50, 125, 100, 35);
		contentPane.add(btn_GAUCHE);
		
		
		
		
		JButton btn_DROITE= new JButton("DROITE");
		btn_DROITE.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				clic_btn_DROITE(50);
			}
		});
		btn_DROITE.setBounds(50, 125, 100, 35);
		contentPane.add(btn_DROITE);
		
		
		
		
		
		
		
		
		
		
	
	}
	
	

}
//Haut.setBounds(170, 50, 100, 35);
//Bas.setBounds(170, 200, 100, 35);
//Gauche.setBounds(50, 125, 100, 35);
//Droite.setBounds(290, 125, 100, 35);
