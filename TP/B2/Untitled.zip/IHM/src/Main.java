
public class Main {

	public static void main(String[] args) {
		Fen2 maFenetre=new Fen2();
		maFenetre.setVisible(true);

	}

}
