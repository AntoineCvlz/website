import java.awt.BorderLayout;
import java.awt.event.KeyListener;
import java.awt.EventQueue;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class Fenetre extends JFrame {

	private JPanel contentPane;
	
	
	
	
	
	
	public Fenetre() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 1000);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		
		
		
		
		JButton b = new JButton("");
		b.setBounds(500, 500, 50, 50);
		contentPane.add(b);
		b.setFocusable(false);
		
		
		
		this.addKeyListener new KeyListener(){
			public void keyPressed(KeyEvent e) {
				if(e.getKeyChar()=='z') {
					
				}
				System.out.println('zzzz');
				
				if(e.getKeyChar()=='s') {
					
				}
				System.out.println('sssss');
				
				if(e.getKeyChar()=='q') {
					
				}
				System.out.println('ZZZZZ');
				
				
			}
		}
		
		
		
		
		
	
	
	}
	
	
	
}
		
		
	


