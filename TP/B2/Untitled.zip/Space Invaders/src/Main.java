
public class Main {

	public static void main(String[] args) {
		Fenetre maFenetre= new Fenetre();
		maFenetre.setVisible(true);

	}
	
	
}
