package portée_variable;

public class Main {

public static void f1(int a) {
	System.out.println(a);
	a=a+1;
	
}
	public static void main(String[] args) {
		
		
		int a=1;
		f1(1);
		System.out.println("eee"+a);
		
		

	}

}
