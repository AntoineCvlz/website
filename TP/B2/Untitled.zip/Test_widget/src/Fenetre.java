import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextPane;
import javax.swing.JComboBox;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Fenetre extends JFrame {

	private JPanel contentPane;

	
	
	public void clic_OK(String p) {
		System.out.println("combobox "+p);
	}
	
	
	
	
	public Fenetre() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 800, 800);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		
		
		JTextPane txtpnChoix = new JTextPane();
		txtpnChoix.setFont(new Font("Hack", Font.ITALIC, 30));
		txtpnChoix.setText("Choix 1");
		txtpnChoix.setBounds(33, 22, 220, 182);
		contentPane.add(txtpnChoix);
		
		
		
		
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(309, 44, 93, 24);
		contentPane.add(comboBox);
		comboBox.addItem("test");
		comboBox.addItem("test2");
		
		
		
		JButton btnNewButton = new JButton("ok");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				clic_OK((String) comboBox.getSelectedItem());
			}
		});
		
		
		btnNewButton.setBounds(309, 125, 147, 60);
		contentPane.add(btnNewButton);
		
		
		
		
		
		
		
		
		
		
		
		
			
		
		
		
		
		
	}
}
